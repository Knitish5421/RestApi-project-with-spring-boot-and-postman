package com.nitish.restapi.service;

public class ServiceMapper {

}
